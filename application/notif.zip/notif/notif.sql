create table comments ( comment_id INT not null primary key,comment_subject VARCHAR(250) not null,comment_text TEXT not null,comment_status INT not null);
